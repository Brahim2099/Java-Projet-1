/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlers;
import Tools.ConnexionBDD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Rakotomalala Cédric
 */
public class CtrlEleve {
    private Connection maCnx;
    private PreparedStatement ps ;
    private ResultSet rs;
    
public CtrlEleve() {
    maCnx= ConnexionBDD.getCnx();
}

}