/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlers;

import Entities.Lecon;
import Tools.ConnexionBDD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Rakotomalala Cédric
 */
public class CtrlLecon {
    private Connection maCnx;
    private PreparedStatement ps ;
    private ResultSet rs;
    
    public CtrlLecon()
    {
        maCnx = ConnexionBDD.getCnx();
    }
    public ArrayList<Lecon> GetLeconByIdEleve(int numEleve){
         ArrayList<Lecon> mesLecons =  new ArrayList<>();
        try {
            ps= maCnx.prepareStatement("SELECT codeLecon,Date,heure,nom,Immatriculation,reglee\n" +
                    "FROM lecon\n" +
                    "Join moniteur on lecon.CodeMoniteur=moniteur.CodeMoniteur\n" +
                    "Where CodeEleve=? AND reglee=0;");
            ps.setInt(1, numEleve);
            rs= ps.executeQuery();
            while(rs.next()){
                Lecon uneLecon= new Lecon(rs.getInt(1), rs.getDate(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6) ) ;
                mesLecons.add(uneLecon);
            }
            ps.close();
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(CtrlLecon.class.getName()).log(Level.SEVERE, null, ex);
        }
        return mesLecons;
    }
    public void AjouterLecon(Date date, String heure){
        
    }
}
