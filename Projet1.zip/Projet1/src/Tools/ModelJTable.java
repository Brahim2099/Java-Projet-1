/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tools;


import Entities.Lecon;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Rakotomalala Cédric
 */
public class ModelJTable extends AbstractTableModel
{
    String[] colonnes;
    Object[][] lignes; 
    
    @Override
    public int getRowCount() {
       return lignes.length;
    }

    @Override
    public int getColumnCount() {
       return colonnes.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) 
    {
        return lignes[rowIndex][columnIndex];
        
    }
    @Override
    public String getColumnName(int column){
        return colonnes[column];
    }
    
    public void LoadDatasLecon(ArrayList<Lecon> mesLecons)
    {
        // Remplir tableaux colonnes
        colonnes = new String []{" Moniteur" , "Date","Heure","Véhicule"};
        lignes = new  Object[mesLecons.size()][4];
        // Remplir le tableau lignes
        int i =0;
        for (Lecon uneLecon : mesLecons)
        {
            lignes[i][0]= uneLecon.getNomMoniteur();
            lignes[i][1]= uneLecon.getDate();
            lignes[i][2]= uneLecon.getHeure();
            lignes[i][3]= uneLecon.getImmatriculation();
            i++;
        }
        //Mettre à jour le JTABLE dans l'interface graphique
        fireTableChanged(null);
    }
// 
//  
//    public void LoadDatasFormation(ArrayList<Formation> desFormations)
//    {
//        // Remplir tableaux colonnes
//        colonnes = new String []{"Numéro" , "Nom"};
//        lignes = new  Object[desFormations.size()][2];
//        // Remplir le tableau lignes
//        int i =0;
//        for (Formation form : desFormations)
//        {
//            lignes[i][0]= form.getIdFormation();
//            lignes[i][1]= form.getNomFormation();
//            i++;
//        }
//        //Mettre à jour le JTABLE dans l'interface graphique
//        fireTableChanged(null);
//    }
}